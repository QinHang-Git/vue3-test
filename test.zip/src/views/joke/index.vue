<template>
  <div>joke</div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent ({
  name:"Joke",
  components: {},
  setup() {
    
    return {
      
    }
  },
})
</script>

<style scoped>

</style>