import { createStore } from 'vuex'
// const moudulesFiles = require.context('./modules',false,/\.js$/)
// const modules = moudulesFiles.keys().reduce((modules,modulePath) => {
//     const value = moudulesFiles(modulePath).default
//     const {name:moduleName, getModule} = value
//     modules[moduleName] = getModule()
//     return modules
//   }
// )
export default createStore({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
